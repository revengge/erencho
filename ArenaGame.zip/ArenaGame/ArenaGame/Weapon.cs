﻿namespace ArenaGame
{
    public abstract class Weapon
    {
        public string Name { get; protected set; }
        public int DamageBonus { get; protected set; }

        public Weapon(string name, int damageBonus)
        {
            Name = name;
            DamageBonus = damageBonus;
        }

        public abstract int CalculateDamage(int baseDamage);
    }

    public class Sword : Weapon
    {
        public Sword() : base("Sword", 25) { }

        public override int CalculateDamage(int baseDamage)
        {
            return baseDamage + DamageBonus;
        }
    }

    public class Dagger : Weapon
    {
        public Dagger() : base("Dagger", 15) { }

        public override int CalculateDamage(int baseDamage)
        {
            // 12% chance to double the attack
            if (Random.Shared.Next(100) < 12)
            {
                return baseDamage + DamageBonus * 2;
            }
            return baseDamage + DamageBonus;
        }
    }

    public class Staff : Weapon
    {
        public Staff() : base("Staff", 30) { }

        public override int CalculateDamage(int baseDamage)
        {
            // 8% chance to triple the attack
            if (Random.Shared.Next(100) < 8)
            {
                return baseDamage + DamageBonus * 3;
            }
            return baseDamage + DamageBonus;
        }
    }

    public class Hammer : Weapon
    {
        public Hammer() : base("Hammer", 20) { }

        public override int CalculateDamage(int baseDamage)
        {
            // 10% chance to quadruple the attack
            if (Random.Shared.Next(100) < 10)
            {
                return baseDamage + DamageBonus * 4;
            }
            return baseDamage + DamageBonus;
        }
    }
}
