﻿namespace ArenaGame
{
    public class Assassin : Hero
    {
        private const int TripleDamageMagicLastDigit = 7;
        private const int HealEachNthRound = 4;
        private int attackCount;

        public Assassin(string name) : base(name)
        {
            attackCount = 0;
        }

        public override int Attack()
        {
            int attack = base.Attack();
            if (attack % 37 == TripleDamageMagicLastDigit)
            {
                attack = attack * 3;
            }
            attackCount = attackCount + 1;
            if (attackCount % HealEachNthRound == 0 && ThrowDice(20))
            {
                Heal(StartingHealth * 50 / 100);
            }
            return attack;
        }

        public override void TakeDamage(int incomingDamage)
        {
            if (ThrowDice(25)) incomingDamage = 0;
            base.TakeDamage(incomingDamage);
        }
    }
}
