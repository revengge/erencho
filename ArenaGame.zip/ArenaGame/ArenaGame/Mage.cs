﻿namespace ArenaGame
{
    public class Sorcerer : Hero
    {
        public Sorcerer(string name) : base(name) { }

        public override int Attack()
        {
            int baseDamage = base.Attack();
            // 25% chance for double attack
            if (ThrowDice(25))
            {
                baseDamage *= 2;
            }
            return baseDamage;
        }

        public override void TakeDamage(int incomingDamage)
        {
            // 15% chance to ignore damage
            if (ThrowDice(15))
            {
                incomingDamage = 0;
            }
            base.TakeDamage(incomingDamage);
        }
    }

    public class Warrior : Hero
    {
        public Warrior(string name) : base(name) { }

        public override int Attack()
        {
            int baseDamage = base.Attack();
            // 20% chance for triple strike

