﻿using ArenaGame;

namespace ConsoleGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number of battles: ");
            int rounds = Int32.Parse(Console.ReadLine());
            int alphaWins = 0, betaWins = 0;

            for (int i = 0; i < rounds; i++)
            {
                // First Battle
                Hero alpha = new Paladin("Leon") { Weapon = new Sword() };
                Hero beta = new Assassin("Shade") { Weapon = new Dagger() };
                Console.WriteLine($"Arena fight between: {alpha.Name} and {beta.Name}");
                Arena arenaOne = new Arena(alpha, beta);
                Hero winnerOne = arenaOne.Battle();
                Console.WriteLine($"Winner of first battle: {winnerOne.Name}");
                if (winnerOne == alpha) alphaWins++; else betaWins++;

                // Second Battle
                Hero gamma = new Sorcerer("Merlin") { Weapon = new Staff() };
                Hero delta = new Warrior("Conan") { Weapon = new Hammer() };
                Console.WriteLine($"Arena fight between: {gamma.Name} and {delta.Name}");
                Arena arenaTwo = new Arena(gamma, delta);
                Hero winnerTwo = arenaTwo.Battle();
                Console.WriteLine($"Winner of second battle: {winnerTwo.Name}");
                if (winnerTwo == gamma) alphaWins++; else betaWins++;

                // Final Battle between the winners of the first two battles
                Console.WriteLine($"Final battle between: {winnerOne.Name} and {winnerTwo.Name}");
                Arena finalArena = new Arena(winnerOne, winnerTwo);
                Hero finalWinner = finalArena.Battle();
                Console.WriteLine($"Winner of the final battle: {finalWinner.Name}");
                if (finalWinner == winnerOne) alphaWins++; else betaWins++;
            }

            Console.WriteLine();
            Console.WriteLine($"Alpha team has {alphaWins} wins.");
            Console.WriteLine($"Beta team has {betaWins} wins.");

            Console.ReadLine();
        }
    }
}
